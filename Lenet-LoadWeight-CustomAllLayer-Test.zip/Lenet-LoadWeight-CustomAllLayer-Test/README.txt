In many research projects (for example, in hardware projects), to perform a specific task (for example, changing the multiplication operation, obtaining the maximum, and implementing different functions based on a new hardware), it is necessary to perform that operation in the Forward functions of the layers. different (for example, changing the desired operation in the layer, based on Stochastic calculations), to do this, we must implement the desired layer as a Custom layer so that we can change its Forward function based on the desired task. Therefore, after writing the Forward function of Convolution layers (instead of nn.conv2d), Maxpooling (instead of nn.maxpool2d), FullyConnected (instead of nn.linear), RELU (instead of nn.RELU) in the network, Train and Test network has also been done.



در بسیاری از پروژه های تحقیقاتی (مثلا در پروژه های سخت افزاری) برای انجام یک کار خاص 
(مثلا تغییر عملیات ضرب، بدست آوردن ماکزیمم و پیاده سازی توابع مختلف براساس یک سخت افزار جدید) نیاز است که آن عملیات را در توابع 
Forward 
لایه های مختلف (مثلا تغییر عملیات موردنظر در لایه، براساس محاسبات 
Stochastic
) تغییر داد، برای انجام این کار باید لایه مورد نظر را به صورت 
Custom layer  
پیاده سازی کرده تا بتوانیم تابع 
Forward 
آن را براساس کار مورد نظر تغییر دهیم. بنابراین بعد از نوشتن تابع 
Forward 
لایه های 
Convolution 
(به جای nn.conv2d)،
 Maxpooling 
(به جای nn.maxpool2d)، 
FullyConnected 
(به جای nn.linear)، 
RELU 
(به جای nn.RELU) 
در شبکه، 
Train و Test 
شبکه نیز انجام شده است.